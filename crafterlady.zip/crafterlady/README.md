# CrafterLady

A craft-supply deals site built with Bootstrap 5 + a little custom CSS — no build step, so it works directly on GitHub Pages. Deal cards are now plain HTML you can copy, paste, and edit directly — no JavaScript or data file involved.

## What's here

```
index.html      Homepage — every deal card lives directly in this file
about.html      About + FTC affiliate disclosure
css/style.css   Header, hero, footer, and brand-color styling
js/main.js      Filtering/search behavior + mobile nav (you shouldn't need to touch this)
```

## Adding or editing a deal

Open `index.html` and search for `id="dealGrid"` — that's where all the cards live, one after another. Each deal looks like this:

```html
<div class="col-12 col-sm-6 col-lg-3 deal-card" data-platform="ebay" data-craft="crochet">
  <div class="card h-100 shadow-sm border-0">
    <div class="card-body d-flex flex-column">
      <span class="badge rounded-pill mb-2 align-self-start badge-ebay">eBay</span>
      <h3 class="h6 fw-bold mb-1">Product title goes here</h3>
      <p class="text-muted small mb-2">Category label</p>
      <p class="small mb-3">Write a normal sentence or two here — this is the description.</p>
      <div class="d-flex align-items-baseline gap-2 mb-3 mt-auto">
        <span class="fw-bold">$14.99</span>
        <span class="text-muted text-decoration-line-through small">$24.99</span>
        <span class="badge bg-light text-dark ms-auto">40% off</span>
      </div>
      <a href="#" target="_blank" rel="noopener sponsored" class="btn btn-sm btn-view w-100">View deal</a>
    </div>
  </div>
</div>
```

**To add a new deal:** copy one whole block (from the outer `<div class="col-12...` down to its closing `</div>`), paste it right after another one, and edit the text inside — title, category, description, price, and the `href="#"` link (put your real affiliate link there).

**To remove a deal:** delete one whole block, same boundaries as above.

**To change the description:** it's just the text inside the `<p class="small mb-3">...</p>` line — type normally, no quotes or commas to worry about.

**Two attributes matter for filtering** (they're at the very top of each card, on the same line as `class="col-12...`):
- `data-platform` — must be exactly one of: `ebay`, `etsy`, `walmart`, `michaels`. This also controls the colored badge — make sure the badge class right below it matches (`badge-ebay`, `badge-etsy`, `badge-walmart`, or `badge-michaels`).
- `data-craft` — one or more of `crochet`, `knitting`, `sewing`, space-separated if more than one (e.g. `data-craft="crochet knitting"` for yarn that works for both).

**If there's no "was" price** (nothing to cross out), just delete this whole line from the card: `<span class="text-muted text-decoration-line-through small">$24.99</span>`

## Get your affiliate links

- **eBay:** eBay Partner Network — runs its own program directly (partnernetwork.ebay.com).
- **Etsy:** applied via Awin — Etsy's affiliate program runs through this network even if you started on Etsy's own site (awin.com).
- **Michaels:** runs through CJ Affiliate / Commission Junction (cj.com).
- **Walmart:** runs through Impact — either the standard affiliate program or the Walmart Creator track (impact.com).

Each has its own dashboard and its own link generator — paste an item's URL in, get back your tracked link, drop that into the `href="#"` on the matching card.

Keep the disclosure box on `about.html` and the footer disclosure text — they're required by FTC guidelines whenever affiliate links are used, across all four programs.

## Host it on GitHub Pages

```bash
git init
git add .
git commit -m "Launch CrafterLady"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
git push -u origin main
```

Then on GitHub: **Settings → Pages → Source → Deploy from a branch → main / (root)**. Your site will be live at `https://YOUR-USERNAME.github.io/YOUR-REPO/` within a minute or two.

## Customize

- Site name/logo: search for "CrafterLady" across the HTML files; the logo mark is the inline `<svg>` in the header.
- Colors/fonts: defined as CSS variables at the top of `css/style.css` (`:root { ... }`) — `--teal` (eBay), `--gold` (Etsy), `--denim` (Walmart), `--plum` (Michaels).
- Newsletter signup currently just shows a confirmation message — connect it to a real provider (Mailchimp, ConvertKit, Buttondown, etc.) by pointing the form at their embed/API.
